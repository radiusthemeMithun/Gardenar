=== Gardenar ===
Contributors: RadiusTheme
Requires at least: 6.4
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.0
License: Envato split License
License URI: https://themeforest.net/licenses/terms/regular

== Description ==

Gardenar is an Responsive Finance and Business WordPress Theme.

== Changelog ==

= 1.0 =
* Released: August 13, 2024

== Copyright ==

Copyright© 2024, RadiusTheme All Rights Reserved.
